from docarray.array.queryset.parser import QueryParser
