import json
import os
import os.path
import warnings
from collections import Counter
from pathlib import Path
from typing import Dict, Type, TYPE_CHECKING, List, Optional, Any, overload
from docarray.helper import get_request_header, __cache_path__, _get_array_info
from docarray.aliyun.ossio import OSSIO, set_oss_env, ENVOSSIO


if TYPE_CHECKING:
    from docarray.typing import T
from functools import wraps

def ossio_init_check(function):
    '''
    time func wrapper
    :param function: function need time
    :return: None
    '''
    @wraps(function)
    def ossio_check_wrapper(*args, **kwargs):
        if ENVOSSIO.is_accessed(object_name='docarray.aliyun.ossio.ENVOSSIO'):
            return function(*args, **kwargs)
    return ossio_check_wrapper

def _get_length_from_summary(summary: List[Dict]) -> Optional[int]:
    """Get the length from summary."""
    for item in summary:
        if 'Length' == item['name']:
            return item['value']

@ossio_init_check
def pull_oss_annlite(r, **kwargs):
    from docarray.array.annlite import DocumentArrayAnnlite
    if isinstance(r, DocumentArrayAnnlite):
        kwargs_storage = kwargs.get('storage', "annlite")
        assert kwargs_storage=="annlite", 'Pulling an DocumentArrayAnnlite from AliyunOSS with init param storage = \'%s\' is Invalid, please set storage=\'annlite\''%kwargs_storage
        kwargs_config = kwargs.get('config', {})
        kwargs_datapath = kwargs_config.get('data_path', None)
        
        if hasattr(r, 'oss_annlite_data_path'):
            oss_annlite_data_path = r.oss_annlite_data_path
            oss_annlite_data_path = oss_annlite_data_path + '/' if not oss_annlite_data_path.endswith('/') else oss_annlite_data_path
            target_data_path = kwargs_datapath if kwargs_datapath is not None else r._config.data_path
            target_data_path = target_data_path + '/' if not target_data_path.endswith('/') else target_data_path
            warnings.warn(
                f'Pulling DocumentArrayAnnlite Object to AliyunOSS, will pull \'{oss_annlite_data_path}\' to \'{r._config.data_path}\''
            )
            ENVOSSIO.copytree(oss_annlite_data_path, target_data_path)
        else:
            raise ValueError('Pull DocumentArrayAnnlite Object from AliyunOSS need oss_annlite_data_path')
    return True

class AliyunOSSPushPullMixin:
    """Transmitting :class:`DocumentArray` via Aliyun OSS Service"""

    _max_bytes = 4.9 * 1024 * 1024 * 1024 # aliyun oss support max 5G file copy

    @ossio_init_check
    def push_oss(
        self,
        name: str,
        branding: Optional[Dict] = None,
    ) -> Dict:
        """Push this DocumentArray object to Aliyun OSS which can be later retrieved via :meth:`.push`

        .. note::
            - Push with the same ``name`` will override the existing content.
            - Kinda like a public clipboard where everyone can override anyone's content.
              So to make your content survive longer, you may want to use longer & more complicated name.
            - The lifetime of the content is not promised atm, could be a day, could be a week. Do not use it for
              persistence. Only use this full temporary transmission/storage/clipboard.

        :param name: a name that later can be used for retrieve this :class:`DocumentArray`.
        :param branding: a dict of branding information to be sent to Jina Cloud. {"icon": "emoji", "background": "#fff"}
        """

        # annlite storage pull should copy database storage file as well
        from docarray.array.annlite import DocumentArrayAnnlite
        if isinstance(self, DocumentArrayAnnlite):
            oss_annlite_data_path = '/'.join(name.split('/')[:-1] + [self._config.data_path])
            warnings.warn(
                f'Pushing DocumentArrayAnnlite Object to AliyunOSS, will push \'{self._config.data_path}\' to \'{oss_annlite_data_path}\''
            )
            ENVOSSIO.copytree(self._config.data_path, oss_annlite_data_path)
            self.oss_annlite_data_path = oss_annlite_data_path

        local_name = name.split('/')[-1]
        self.save(local_name)
        ENVOSSIO.copy(local_name, name)
        return 
    
    @classmethod
    @ossio_init_check
    def pull_oss(
        cls: Type['T'],
        name: str,
        show_progress: bool = False,
        local_cache: bool = True,
        *args,
        **kwargs,
    ) -> 'T':
        """Pulling a :class:`DocumentArray` from Jina Cloud Service to local.

        :param name: the upload name set during :meth:`.push`
        :param show_progress: if to show a progress bar on pulling
        :param local_cache: store the downloaded DocumentArray to local folder
        :return: a :class:`DocumentArray` object
        """

        lname = name.split('/')[-1]
        Path(__cache_path__).mkdir(parents=True, exist_ok=True)
        tname = f'{__cache_path__}/{lname}'

        ENVOSSIO.copy(name, tname)
        r = cls.load_binary(tname, *args, **kwargs)

        #pull annlite database from aliyun oss if r is DocumentArrayAnnlite Object
        is_annlite = pull_oss_annlite(r, **kwargs)
        
        if is_annlite:
            del r
            r =  cls.load(tname,
                *args,
                **kwargs)

        return r


