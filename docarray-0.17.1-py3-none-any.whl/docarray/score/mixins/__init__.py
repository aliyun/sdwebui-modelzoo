from docarray.score.mixins.property import PropertyMixin
from docarray.score.mixins.representer import RepresentMixin


class AllMixins(RepresentMixin, PropertyMixin):
    ...
